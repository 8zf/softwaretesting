var xlsx = require('node-xlsx').default;

// Parse a file
const workSheetsFromFile = xlsx.parse("data/telephone-fare-test.xlsx");

console.log(workSheetsFromFile[0].data);