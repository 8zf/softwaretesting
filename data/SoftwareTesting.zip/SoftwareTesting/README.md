# softwaretesting
这是一个软件测试作业repo

> 每个README都有我说的话 ——鲁迅
