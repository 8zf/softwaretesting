'use strict';
const accuracy = 1e-6;
let telephone_fare = require('./../program/telephone-fare');
let expect = require('chai').expect;
let xlsx = require('node-xlsx').default;
let workSheetsFromFile = xlsx.parse("./data/telephone-fare-test.xlsx");
let datas = workSheetsFromFile[0].data;
describe('话费计算', () => {
	for (let data of datas) {
		it(data[3], ()=>{
			expect(telephone_fare.getTelephoneFare(parseFloat(data[1]), parseFloat(data[2])).toFixed(5)).to.be.equal(data[4].toFixed(5));
		});
	}
});