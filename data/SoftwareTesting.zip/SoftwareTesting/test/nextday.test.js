'use strict';
const accuracy = 1e-6;
let next_day = require('./../program/nextday');
let expect = require('chai').expect;
let xlsx = require('node-xlsx').default;
let workSheetsFromFile = xlsx.parse("./data/nextday-test.xlsx");
let datas = workSheetsFromFile[0].data;
describe('话费计算', () => {
	for (let data of datas) {
		it(data[4], ()=>{
			expect(next_day(parseInt(data[1]), parseInt(data[2]), parseInt(data[3]))).to.be.equal(data[4]);
		});
	}
});