'use strict';
const rate = [[1, 0.01], [2, 0.015], [3, 0.02], [3, 0.025], [6, 0.03]];
const month_rent = 25;
const minute_rent = 0.15;
function getTelephoneFare(minutes, late_times) {
	let discount = 1;
	if (late_times <= rate[Math.ceil(minutes / 60) - 1][0])
		discount = 1 - rate[Math.ceil(minutes / 60) - 1][1];
	let fare = month_rent + minutes * minute_rent * discount;
	return fare;
}
module.exports = {
	rate: rate,
	month_rent: month_rent,
	minute_rent: minute_rent,
	getTelephoneFare: getTelephoneFare
};