'use strict';
let Year = 0, Month = 0, Day = 0, NextDay = 0;
let LeapYear_Month_SumDay = [ 31,29,31,30,31,30,31,31,30,31,30,31 ];//闰年数组，保存各月天数。

function IsLeapYear(Year) {
	if (Year % 4 == 0)
	{
		if (Year % 400) return 1;
		else
		{
			if (Year % 100 == 0) return 0;
			else return 1;
		}
	}
	else
	{
		return 0;
	}
}

function IsCurrentDate( Year,  Month,  Day) {
	if ((Year < 0) || (Year > 9999) || (Month > 12) || (Month < 1) || (Day < 1) || (Day > 31))
		return 0;
	else
		return 1;
}

function ReturnNextDay( Year,  Month,  Day) {
	let ThisMonthSumDay;
	let result;
	if (IsCurrentDate(Year, Month, Day) == 1)
	{
		ThisMonthSumDay = LeapYear_Month_SumDay[Month - 1];
		if (Month == 2)
		{
			if (IsLeapYear(Year) == 0) ThisMonthSumDay--;
		}
		if (Day < ThisMonthSumDay)
			result = ++Day;
		else
		{
			if (Day == ThisMonthSumDay)
				Day = result = 1;
			else
				result = 0;
		}
	}
	else
		result = 0;
	switch (result)
	{
		case 0: return "not a correct date";
			break;
		case 1:
			if (Month == 12)
			{
				Year++;
				Month = 1;
			}
			else
				Month++;
			break;
	}
	return Year + '-' + Month + '-' + Day;
}

module.exports = ReturnNextDay;

// console.log(ReturnNextDay(2008,2,28));